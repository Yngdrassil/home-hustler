<?php
    require_once("../vendor/autoload.php");

    $reso_client_id = '3z8w7WfWtednQy3QhhWh';
    $eia_api_key = '7e98579fe8df595c44af2d056523f420';    //utility cost including electricity, gas

    $attom_api_key = 'a38f76c6891995290466517ef9c81623';

    function reso_call() {
        $url = "https://api.bridgedataoutput.com/api/v2/test/listings?access_token=6baca547742c6f96a6ff71b138424f21";
        $result = file_get_contents($url);
        //$data = simplexml_load_string($result);

        echo "<tr>$result</tr>";
    }

    function zillow_call() {
        $zillow_id = 'X1-ZWz1gybz2dapl7_86zet';
        $search = "208-wrentree-drive"; //$_GET['address'];
        $citystate = "Easley,SC"; //$_GET['citystate'];
        $address = urlencode($search);
        $citystatezip = urlencode($citystate);
        $url = "http://www.zillow.com/webservice/GetSearchResults.htm?zws-id=$zillow_id&address=$address&citystatezip=$citystatezip";
        $result = file_get_contents($url);
        $data = simplexml_load_string($result);

        echo "<tr>$data</tr>";
    }

 ?>
