#!/usr/bin/perl

print "Location: www.home-hustler.com/index.html";
