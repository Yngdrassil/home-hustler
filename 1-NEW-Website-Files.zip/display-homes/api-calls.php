<?php

    $attom_api_key = 'a38f76c6891995290466517ef9c81623';

    function zillow_call() {
        $zillow_id = 'X1-ZWz1gybz2dapl7_86zet';
        $search = "208-wrentree-drive"; //$_GET['address'];
        $citystate = "Easley,SC"; //$_GET['citystate'];
        $address = urlencode($search);
        $citystatezip = urlencode($citystate);
        $url = "http://www.zillow.com/webservice/GetSearchResults.htm?zws-id=$zillow_id&address=$address&citystatezip=$citystatezip";
        $result = file_get_contents($url);
        $data = simplexml_load_string($result);

        echo "<tr>$data</tr>";
    }

 ?>
