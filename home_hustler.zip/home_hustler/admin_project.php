<?php
	session_start();
	require_once "./functions/admin.php";
	$title = "List note";
	require_once "./template/header.php";
	require_once "./functions/database_functions.php";
	$conn = db_connect();
?>
	<a href="admin_signout.php" class="btn btn-primary">Sign out!</a>

<?php
	if(isset($conn)) {mysqli_close($conn);}
	require_once "./template/footer.php";
?>
