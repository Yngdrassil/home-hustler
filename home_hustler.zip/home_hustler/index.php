<?php
  session_start();
  $count = 0;
  // connecto database

  $title = "Index";
  require_once "./template/header.php";
  require_once "./functions/database_functions.php";
  $conn = db_connect();
?>
      <!-- Example row of columns -->
      <p class="lead text-center text-muted">Team Members</p>
      <div class="row">
          <div class="col-lg-4 col-md-6 wow fadeIn" data-wow-delay=".2s">
          <h4 style="text-align:center">Blake Edens</h4>
          <p><img src="bootstrap/img/mattia.png" class="img-responsive center-block" width="200" height="200"></p>
        </div>
        <div class="col-lg-4 col-md-6 wow fadeIn" data-wow-delay=".4s">
          <h4 style="text-align:center">Waylon Ergle</h4>
          <p><img src="bootstrap/img/mattia.png" class="img-responsive center-block" width="200" height="200"></p>
        </div>
        <div class="col-lg-4 col-md-6 wow fadeIn" data-wow-delay=".6s">
          <h4 style="text-align:center">Mattia Galanti</h4>
          <p><img src="bootstrap/img/mattia.png" class="img-responsive center-block" width="200" height="200"></p>
          <h5 style="text-align:center"><br />LANDER UNIVERSITY<br>CIS MAJOR<br>EMPHASIS IN SOFTWARE DEVELOPMENT</b></h5>
        </div>
      	</div>

<?php
  if(isset($conn)) {mysqli_close($conn);}
  require_once "./template/footer.php";
?>
